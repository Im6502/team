<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Item Report - Digital Lost & Found</title>
    <link rel="stylesheet" href="CSS/forms.css">
</head>
<body>
    <div class="login-container">
        <div class="left">
            <h1>Digital Lost & Found</h1>
        </div>
        <div class="right">
            <h2>Please tell us more about this item that you have found</h2>

            <?php
            // Check if form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Get form data
                $item_type = $_POST['question1'];
                $color = $_POST['question2'];
                $location = $_POST['question3'];
                $description = $_POST['question4'];
                $name = $_POST['question5'];

                // Store form data in a text file (for demonstration)
                $file = fopen("found_items.txt", "a");
                fwrite($file, "Item Type: $item_type\nColor: $color\nLocation: $location\nDescription: $description\nName: $name\n\n");
                fclose($file);

                echo "<p>Thank you for your submission!</p>";
            }
            ?>

            <form method="post">
                <div class="input-group">
                    <p>What type of item have you found</p>
                    <textarea id="Q1" name="question1" placeholder="e.g. A phone, hoodie, coffee mug, cockroach etc" rows="1" required></textarea>
                </div>
                <div class="input-group">
                    <p>What is the colour of your item?</p>
                    <textarea id="Q2" name="question2" placeholder="If it has multiple colours please state." rows="1" required></textarea>
                </div>
                <div class="input-group">
                    <p>When and where did you locate the item? *If known*</p>
                    <textarea id="Q3" name="question3" placeholder="Please be as specific as possible" rows="4"></textarea>
                </div>
                <div class="input-group">
                    <p>Describe some important details about the item.</p>
                    <textarea id="Q4" name="question4" placeholder="For example the item may have bullet holes or a name written on it" rows="4" required></textarea>
                </div>
                <div class="input-group">
                    <p>Also, please enter your name.</p>
                    <textarea id="Q5" name="question5" placeholder="Your legal name" rows="4" required></textarea>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Digital Lost & Found. All rights reserved.</p>
    </footer>
</body>
</html>

const sqlite3 = require('sqlite3').verbose();

// Connect to the database
const db = new sqlite3.Database("./DDDatabase.db", sqlite3.OPEN_READWRITE, (err) => {
    if (err) return console.error(err.message);
    console.log('Please stand by. The database is being automatically connected.');
});

// Define SQL query
const sql = 'SELECT * FROM lost';

// Execute query to select data from the table
db.all(sql, [], (err, rows) => {
    if (err) {
        console.error(err.message);
    }
    // Process the retrieved data
    rows.forEach((row) => {
        console.log(row); // Output each row to the console
    });
});

// Close the database connection
db.close((err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('The connection has now been terminated.');
});

<?php
if (extension_loaded('pdo_sqlite')) {
    echo 'PDO SQLite extension is enabled.';
} else {
    echo 'PDO SQLite extension is not enabled.';
}

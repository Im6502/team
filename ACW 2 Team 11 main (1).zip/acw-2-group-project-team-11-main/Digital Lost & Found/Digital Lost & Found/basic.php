<?php
// Connect to the database
$db = new SQLite3('DDDatabase.db');

// Query database to retrieve items
$query = "SELECT * FROM lost";
$result = $db->query($query);

// Display items
echo "<h1>Found Items</h1>";
echo "<ul>";
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    echo "<li>Item ID: " . $row['itemId'] . ", Finder: " . $row['Finder'] . ", Type: " . $row['ItemType'] . ", Colour: " . $row['Colour'] . ", Location: " . $row['Location'] . ", Description: " . $row['Description'] . "</li>";
}
echo "</ul>";

// Close database connection
$db->close();


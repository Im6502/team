const express = require('express');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

// Connect to the database
const db = new sqlite3.Database("./DDDatabase.db", sqlite3.OPEN_READWRITE, (err) => {
    if (err) return console.error(err.message);
    console.log('Connected to the database.');
});

// Define endpoint to retrieve data
app.get('/items', (req, res) => {
    // Define SQL query
    const sql = 'SELECT * FROM LostItems';

    // Execute query to select data from the table
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(rows);
    });
});

// Serve HTML file
app.use(express.static('public'));

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${55545}`);
});
